from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import hashlib
import json

app = Flask(__name__)
CORS(app)

users = {}
dataset = None
blockchain = []

# ---------------- BLOCKCHAIN ----------------
def hash_data(data):
    return hashlib.sha256(data.encode()).hexdigest()

def add_block(data):
    prev_hash = blockchain[-1]['hash'] if blockchain else "0"
    new_hash = hash_data(json.dumps(data) + prev_hash)

    block = {
        "data": data,
        "prev_hash": prev_hash,
        "hash": new_hash
    }

    blockchain.append(block)

# ---------------- REGISTER ----------------
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    users[data['username']] = data['password']
    return jsonify({"message": "User registered successfully"})

# ---------------- LOGIN ----------------
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    if data['username'] in users and users[data['username']] == data['password']:
        return jsonify({"message": "Login success"})
    return jsonify({"message": "Invalid credentials"})

# ---------------- UPLOAD DATASET ----------------
@app.route('/upload_dataset', methods=['POST'])
def upload_dataset():
    global dataset

    dataset = pd.DataFrame({
        "Age": [25, 40, 35, 50],
        "BP": [120, 140, 130, 150],
        "Cholesterol": [200, 240, 220, 260]
    })

    add_block({"action": "Dataset uploaded"})
    return jsonify({"message": "Dataset uploaded & stored in blockchain"})

# ---------------- ANALYTICS ----------------
@app.route('/advanced_analytics', methods=['GET'])
def advanced_analytics():
    global dataset

    if dataset is None:
        return jsonify({"message": "No dataset uploaded"})

    avg_bp = dataset["BP"].mean()
    risk = "High BP Risk" if avg_bp > 140 else "Normal"

    result = {
        "Average Age": float(dataset["Age"].mean()),
        "Average Cholesterol": float(dataset["Cholesterol"].mean()),
        "Max BP": int(dataset["BP"].max()),
        "Min BP": int(dataset["BP"].min()),
        "Health Risk": risk
    }

    add_block(result)
    return jsonify(result)

# ---------------- VIEW BLOCKCHAIN ----------------
@app.route('/blockchain', methods=['GET'])
def view_blockchain():
    return jsonify(blockchain)

# ---------------- RUN ----------------
if __name__ == '__main__':
    app.run(debug=True)
